import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birlasoft-noida',
  templateUrl: './birlasoft-noida.component.html',
  styleUrls: ['./birlasoft-noida.component.css']
})
export class BirlasoftNoidaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { ReversecharPipe } from './reversechar.pipe';

describe('ReversecharPipe', () => {
  it('create an instance', () => {
    const pipe = new ReversecharPipe();
    expect(pipe).toBeTruthy();
  });
});

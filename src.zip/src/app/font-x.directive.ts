import { Directive } from '@angular/core';

@Directive({
  selector: '[appFontX]'
})
export class FontXDirective {

  constructor() { }

}

import { FontXDirective } from './font-x.directive';

describe('FontXDirective', () => {
  it('should create an instance', () => {
    const directive = new FontXDirective();
    expect(directive).toBeTruthy();
  });
});

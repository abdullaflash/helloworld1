import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-two',
  templateUrl: './branch-two.component.html',
  styleUrls: ['./branch-two.component.css']
})
export class BranchTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-one',
  templateUrl: './branch-one.component.html',
  styleUrls: ['./branch-one.component.css']
})
export class BranchOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

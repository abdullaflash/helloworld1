import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birlasoft-chennai',
  templateUrl: './birlasoft-chennai.component.html',
  styleUrls: ['./birlasoft-chennai.component.css']
})
export class BirlasoftChennaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { FontcolorDirective } from './fontcolor.directive';

describe('FontcolorDirective', () => {
  it('should create an instance', () => {
    const directive = new FontcolorDirective();
    expect(directive).toBeTruthy();
  });
});
